#ifndef __wasilibc___typedef_sigset_t_h
#define __wasilibc___typedef_sigset_t_h

                                                                            
typedef unsigned char sigset_t;

#endif
