#ifndef __wasm_basics___typedef_clock_t_h
#define __wasm_basics___typedef_clock_t_h

                                                                  
typedef long long clock_t;

#endif
