#ifndef __wasm_basics___typedef_time_t_h
#define __wasm_basics___typedef_time_t_h

                                                                   
typedef long long time_t;

#endif
