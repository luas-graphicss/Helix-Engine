              
                                                                                
  
                                                       
  
                                                                               
                                                
  
                                                                                

#ifndef _LIBCPP_COMPLEX_H
#define _LIBCPP_COMPLEX_H

 

#include <__config>

#if !defined(_LIBCPP_HAS_NO_PRAGMA_SYSTEM_HEADER)
#pragma GCC system_header
#endif

#ifdef __cplusplus

#include <ccomplex>

#else                

#include_next <complex.h>

#endif                

#endif                      
