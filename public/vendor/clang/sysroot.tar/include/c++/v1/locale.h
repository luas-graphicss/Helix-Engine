              
                                                                                
  
                                                       
  
                                                                               
                                                
  
                                                                                

#ifndef _LIBCPP_LOCALE_H
#define _LIBCPP_LOCALE_H

 

#include <__config>

#if !defined(_LIBCPP_HAS_NO_PRAGMA_SYSTEM_HEADER)
#pragma GCC system_header
#endif

#include_next <locale.h>

#endif                     
