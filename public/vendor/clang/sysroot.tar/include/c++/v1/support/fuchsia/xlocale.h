              
                                                                                
  
                                                       
  
                                                                               
                                                
  
                                                                                

#ifndef _LIBCPP_SUPPORT_FUCHSIA_XLOCALE_H
#define _LIBCPP_SUPPORT_FUCHSIA_XLOCALE_H

#if defined(__Fuchsia__)

#include <cstdlib>
#include <cwchar>
#include <support/xlocale/__posix_l_fallback.h>
#include <support/xlocale/__strtonum_fallback.h>

#endif                        

#endif                                     
