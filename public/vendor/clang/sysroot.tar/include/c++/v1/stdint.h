              
                                                                                
  
                                                       
  
                                                                        
                                        
  
                                                                                

#ifndef _LIBCPP_STDINT_H
#define _LIBCPP_STDINT_H

 

#include <__config>

#if !defined(_LIBCPP_HAS_NO_PRAGMA_SYSTEM_HEADER)
#pragma GCC system_header
#endif

 
#if defined(__cplusplus) && !defined(__STDC_LIMIT_MACROS)
#   define __STDC_LIMIT_MACROS
#endif
#if defined(__cplusplus) && !defined(__STDC_CONSTANT_MACROS)
#   define __STDC_CONSTANT_MACROS
#endif

#include_next <stdint.h>

#endif                     
