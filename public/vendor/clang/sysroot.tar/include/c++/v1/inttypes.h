              
                                                                                
  
                                                       
  
                                                                        
                                        
  
                                                                                

#ifndef _LIBCPP_INTTYPES_H
#define _LIBCPP_INTTYPES_H

 

#include <__config>

#if !defined(_LIBCPP_HAS_NO_PRAGMA_SYSTEM_HEADER)
#pragma GCC system_header
#endif

 
#if defined(__cplusplus) && !defined(__STDC_FORMAT_MACROS)
#   define __STDC_FORMAT_MACROS
#endif

#include_next <inttypes.h>

#ifdef __cplusplus

#include <stdint.h>

#undef imaxabs
#undef imaxdiv

#endif               

#endif                       
