              
                                                                                
  
                                                       
  
                                                                               
                                                
  
                                                                                

#ifndef _LIBCPP_TGMATH_H
#define _LIBCPP_TGMATH_H

 

#include <__config>

#if !defined(_LIBCPP_HAS_NO_PRAGMA_SYSTEM_HEADER)
#pragma GCC system_header
#endif

#ifdef __cplusplus

#include <ctgmath>

#else                

#include_next <tgmath.h>

#endif                

#endif                     
