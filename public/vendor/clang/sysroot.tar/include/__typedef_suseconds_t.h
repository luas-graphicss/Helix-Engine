#ifndef __wasm_basics___typedef_suseconds_t_h
#define __wasm_basics___typedef_suseconds_t_h

 
typedef long long suseconds_t;

#endif
