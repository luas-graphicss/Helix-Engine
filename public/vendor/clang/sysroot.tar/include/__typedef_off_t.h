#ifndef __wasm_basics___typedef_off_t_h
#define __wasm_basics___typedef_off_t_h

                                                                                
typedef long long off_t;

#endif
