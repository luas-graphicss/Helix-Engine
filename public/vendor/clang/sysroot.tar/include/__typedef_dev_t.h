#ifndef __wasm_basics___typedef_dev_t_h
#define __wasm_basics___typedef_dev_t_h

                                                                     
typedef unsigned long long dev_t;

#endif
