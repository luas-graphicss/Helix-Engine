#ifndef __wasm_basics___typedef_blkcnt_t_h
#define __wasm_basics___typedef_blkcnt_t_h

                                                                                
typedef long long blkcnt_t;

#endif
