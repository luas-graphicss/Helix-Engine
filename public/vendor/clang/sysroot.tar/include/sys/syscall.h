#ifndef _SYS_SYSCALL_H
#define _SYS_SYSCALL_H

#ifdef __wasilibc_unmodified_upstream                          
#include <bits/syscall.h>
#else
                                                         
#endif

#endif
