#ifndef __wasm_basics___typedef_nlink_t_h
#define __wasm_basics___typedef_nlink_t_h

                                                                            
typedef unsigned long long nlink_t;

#endif
