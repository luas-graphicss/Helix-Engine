#ifndef __wasm_basics___typedef_ino_t_h
#define __wasm_basics___typedef_ino_t_h

                                                                    
typedef unsigned long long ino_t;

#endif
