#ifndef __wasm_basics___macro_PAGESIZE_h
#define __wasm_basics___macro_PAGESIZE_h

 
#define PAGESIZE (0x10000)

#endif
