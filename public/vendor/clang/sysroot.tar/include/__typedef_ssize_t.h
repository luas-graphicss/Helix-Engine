#ifndef __wasm_basics___typedef_ssize_t_h
#define __wasm_basics___typedef_ssize_t_h

                                                    
typedef long ssize_t;

#endif
