#ifndef __wasi_libc_find_relpath_h
#define __wasi_libc_find_relpath_h

#ifdef __cplusplus
extern "C" {
#endif

 
int __wasilibc_find_relpath(const char *path,
                            __wasi_rights_t rights_base,
                            __wasi_rights_t rights_inheriting,
                            const char **relative_path);

#ifdef __cplusplus
}
#endif

#endif
