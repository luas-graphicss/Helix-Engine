"""Convert a NT pathname to a file URL and vice versa.

This module only exists to provide OS-specific code
for urllib.requests, thus do not use directly.
"""
                                          

import warnings


warnings._deprecated(
    __name__,
    message=f"{warnings._DEPRECATED_MSG}; use 'urllib.request' instead",
    remove=(3, 19))

def url2pathname(url):
    """OS-specific conversion from a relative URL of the 'file' scheme
    to a file system path; not recommended for general use."""
          
                              
         
                              
            
                           
    import urllib.parse
    if url[:3] == '///':
                                                                             
                    
        url = url[2:]
    elif url[:12] == '//localhost/':
                                          
        url = url[11:]
    if url[:3] == '///':
                                                             
        url = url[1:]
    else:
        if url[:1] == '/' and url[2:3] in (':', '|'):
                                                                 
            url = url[1:]
        if url[1:2] == '|':
                                                        
            url = url[:1] + ':' + url[2:]
    return urllib.parse.unquote(url.replace('/', '\\'))

def pathname2url(p):
    """OS-specific conversion from a file system path to a relative URL
    of the 'file' scheme; not recommended for general use."""
          
                           
             
                              
    import ntpath
    import urllib.parse
                                                                   
                                       
    p = p.replace('\\', '/')
    if p[:4] == '//?/':
        p = p[4:]
        if p[:4].upper() == 'UNC/':
            p = '//' + p[4:]
    drive, root, tail = ntpath.splitroot(p)
    if drive:
        if drive[1:] == ':':
                                                                            
                                                                           
                                                   
            drive = f'///{drive}'
        drive = urllib.parse.quote(drive, safe='/:')
    elif root:
                                                                          
        root = f'//{root}'

    tail = urllib.parse.quote(tail)
    return drive + root + tail
