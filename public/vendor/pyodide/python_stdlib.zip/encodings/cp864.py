""" Python Character Mapping Codec generated from 'VENDORS/MICSFT/PC/CP864.TXT' with gencodec.py.

"""  

import codecs

              

class Codec(codecs.Codec):

    def encode(self,input,errors='strict'):
        return codecs.charmap_encode(input,errors,encoding_map)

    def decode(self,input,errors='strict'):
        return codecs.charmap_decode(input,errors,decoding_table)

class IncrementalEncoder(codecs.IncrementalEncoder):
    def encode(self, input, final=False):
        return codecs.charmap_encode(input,self.errors,encoding_map)[0]

class IncrementalDecoder(codecs.IncrementalDecoder):
    def decode(self, input, final=False):
        return codecs.charmap_decode(input,self.errors,decoding_table)[0]

class StreamWriter(Codec,codecs.StreamWriter):
    pass

class StreamReader(Codec,codecs.StreamReader):
    pass

                        

def getregentry():
    return codecs.CodecInfo(
        name='cp864',
        encode=Codec().encode,
        decode=Codec().decode,
        incrementalencoder=IncrementalEncoder,
        incrementaldecoder=IncrementalDecoder,
        streamreader=StreamReader,
        streamwriter=StreamWriter,
    )

                

decoding_map = codecs.make_identity_dict(range(256))
decoding_map.update({
    0x0025: 0x066a,                           
    0x0080: 0x00b0,                   
    0x0081: 0x00b7,                  
    0x0082: 0x2219,                       
    0x0083: 0x221a,                   
    0x0084: 0x2592,                    
    0x0085: 0x2500,                              
    0x0086: 0x2502,                            
    0x0087: 0x253c,                                           
    0x0088: 0x2524,                                     
    0x0089: 0x252c,                                       
    0x008a: 0x251c,                                      
    0x008b: 0x2534,                                     
    0x008c: 0x2510,                                 
    0x008d: 0x250c,                                  
    0x008e: 0x2514,                                
    0x008f: 0x2518,                               
    0x0090: 0x03b2,                        
    0x0091: 0x221e,                
    0x0092: 0x03c6,                       
    0x0093: 0x00b1,                          
    0x0094: 0x00bd,                    
    0x0095: 0x00bc,                    
    0x0096: 0x2248,                       
    0x0097: 0x00ab,                               
    0x0098: 0x00bb,                                
    0x0099: 0xfef7,                                                                    
    0x009a: 0xfef8,                                                                 
    0x009b: None,                   
    0x009c: None,                   
    0x009d: 0xfefb,                                                   
    0x009e: 0xfefc,                                                
    0x009f: None,                   
    0x00a1: 0x00ad,                   
    0x00a2: 0xfe82,                                                      
    0x00a5: 0xfe84,                                                      
    0x00a6: None,                   
    0x00a7: None,                   
    0x00a8: 0xfe8e,                                     
    0x00a9: 0xfe8f,                                       
    0x00aa: 0xfe95,                                       
    0x00ab: 0xfe99,                                        
    0x00ac: 0x060c,                    
    0x00ad: 0xfe9d,                                        
    0x00ae: 0xfea1,                                       
    0x00af: 0xfea5,                                        
    0x00b0: 0x0660,                               
    0x00b1: 0x0661,                              
    0x00b2: 0x0662,                              
    0x00b3: 0x0663,                                
    0x00b4: 0x0664,                               
    0x00b5: 0x0665,                               
    0x00b6: 0x0666,                              
    0x00b7: 0x0667,                                
    0x00b8: 0x0668,                                
    0x00b9: 0x0669,                               
    0x00ba: 0xfed1,                                       
    0x00bb: 0x061b,                        
    0x00bc: 0xfeb1,                                        
    0x00bd: 0xfeb5,                                         
    0x00be: 0xfeb9,                                       
    0x00bf: 0x061f,                            
    0x00c0: 0x00a2,                 
    0x00c1: 0xfe80,                                         
    0x00c2: 0xfe81,                                                         
    0x00c3: 0xfe83,                                                         
    0x00c4: 0xfe85,                                                        
    0x00c5: 0xfeca,                                    
    0x00c6: 0xfe8b,                                                       
    0x00c7: 0xfe8d,                                        
    0x00c8: 0xfe91,                                      
    0x00c9: 0xfe93,                                               
    0x00ca: 0xfe97,                                      
    0x00cb: 0xfe9b,                                       
    0x00cc: 0xfe9f,                                       
    0x00cd: 0xfea3,                                      
    0x00ce: 0xfea7,                                       
    0x00cf: 0xfea9,                                       
    0x00d0: 0xfeab,                                        
    0x00d1: 0xfead,                                       
    0x00d2: 0xfeaf,                                        
    0x00d3: 0xfeb3,                                       
    0x00d4: 0xfeb7,                                        
    0x00d5: 0xfebb,                                      
    0x00d6: 0xfebf,                                      
    0x00d7: 0xfec1,                                       
    0x00d8: 0xfec5,                                       
    0x00d9: 0xfecb,                                      
    0x00da: 0xfecf,                                        
    0x00db: 0x00a6,                           
    0x00dc: 0x00ac,                
    0x00dd: 0x00f7,                     
    0x00de: 0x00d7,                           
    0x00df: 0xfec9,                                       
    0x00e0: 0x0640,                      
    0x00e1: 0xfed3,                                      
    0x00e2: 0xfed7,                                      
    0x00e3: 0xfedb,                                      
    0x00e4: 0xfedf,                                      
    0x00e5: 0xfee3,                                       
    0x00e6: 0xfee7,                                       
    0x00e7: 0xfeeb,                                      
    0x00e8: 0xfeed,                                       
    0x00e9: 0xfeef,                                                
    0x00ea: 0xfef3,                                      
    0x00eb: 0xfebd,                                       
    0x00ec: 0xfecc,                                     
    0x00ed: 0xfece,                                      
    0x00ee: 0xfecd,                                         
    0x00ef: 0xfee1,                                        
    0x00f0: 0xfe7d,                                 
    0x00f1: 0x0651,                      
    0x00f2: 0xfee5,                                        
    0x00f3: 0xfee9,                                       
    0x00f4: 0xfeec,                                     
    0x00f5: 0xfef0,                                             
    0x00f6: 0xfef2,                                    
    0x00f7: 0xfed0,                                       
    0x00f8: 0xfed5,                                       
    0x00f9: 0xfef5,                                                                    
    0x00fa: 0xfef6,                                                                 
    0x00fb: 0xfedd,                                       
    0x00fc: 0xfed9,                                       
    0x00fd: 0xfef1,                                       
    0x00fe: 0x25a0,                    
    0x00ff: None,                   
})

                  

decoding_table = (
    '\x00'                      
    '\x01'                                  
    '\x02'                               
    '\x03'                             
    '\x04'                                     
    '\x05'                         
    '\x06'                             
    '\x07'                      
    '\x08'                           
    '\t'                                         
    '\n'                             
    '\x0b'                                     
    '\x0c'                           
    '\r'                                   
    '\x0e'                           
    '\x0f'                          
    '\x10'                                  
    '\x11'                                    
    '\x12'                                    
    '\x13'                                      
    '\x14'                                     
    '\x15'                                      
    '\x16'                                  
    '\x17'                                           
    '\x18'                        
    '\x19'                               
    '\x1a'                            
    '\x1b'                        
    '\x1c'                                
    '\x1d'                                 
    '\x1e'                                  
    '\x1f'                                
    ' '                          
    '!'                                     
    '"'                                   
    '#'                                
    '$'                                
    '\u066a'                                   
    '&'                              
    "'"                               
    '('                                     
    ')'                                      
    '*'                             
    '+'                              
    ','                          
    '-'                                 
    '.'                              
    '/'                            
    '0'                               
    '1'                              
    '2'                              
    '3'                                
    '4'                               
    '5'                               
    '6'                              
    '7'                                
    '8'                                
    '9'                               
    ':'                          
    ';'                              
    '<'                                   
    '='                                
    '>'                                      
    '?'                                  
    '@'                                  
    'A'                                           
    'B'                                           
    'C'                                           
    'D'                                           
    'E'                                           
    'F'                                           
    'G'                                           
    'H'                                           
    'I'                                           
    'J'                                           
    'K'                                           
    'L'                                           
    'M'                                           
    'N'                                           
    'O'                                           
    'P'                                           
    'Q'                                           
    'R'                                           
    'S'                                           
    'T'                                           
    'U'                                           
    'V'                                           
    'W'                                           
    'X'                                           
    'Y'                                           
    'Z'                                           
    '['                                        
    '\\'                                   
    ']'                                         
    '^'                                      
    '_'                             
    '`'                                 
    'a'                                         
    'b'                                         
    'c'                                         
    'd'                                         
    'e'                                         
    'f'                                         
    'g'                                         
    'h'                                         
    'i'                                         
    'j'                                         
    'k'                                         
    'l'                                         
    'm'                                         
    'n'                                         
    'o'                                         
    'p'                                         
    'q'                                         
    'r'                                         
    's'                                         
    't'                                         
    'u'                                         
    'v'                                         
    'w'                                         
    'x'                                         
    'y'                                         
    'z'                                         
    '{'                                       
    '|'                                  
    '}'                                        
    '~'                          
    '\x7f'                        
    '\xb0'                             
    '\xb7'                            
    '\u2219'                               
    '\u221a'                           
    '\u2592'                            
    '\u2500'                                      
    '\u2502'                                    
    '\u253c'                                                   
    '\u2524'                                             
    '\u252c'                                               
    '\u251c'                                              
    '\u2534'                                             
    '\u2510'                                         
    '\u250c'                                          
    '\u2514'                                        
    '\u2518'                                       
    '\u03b2'                                
    '\u221e'                        
    '\u03c6'                               
    '\xb1'                                    
    '\xbd'                              
    '\xbc'                              
    '\u2248'                               
    '\xab'                                         
    '\xbb'                                          
    '\ufef7'                                                                            
    '\ufef8'                                                                         
    '\ufffe'                         
    '\ufffe'                         
    '\ufefb'                                                           
    '\ufefc'                                                        
    '\ufffe'                         
    '\xa0'                                    
    '\xad'                             
    '\ufe82'                                                              
    '\xa3'                            
    '\xa4'                               
    '\ufe84'                                                              
    '\ufffe'                         
    '\ufffe'                         
    '\ufe8e'                                             
    '\ufe8f'                                               
    '\ufe95'                                               
    '\ufe99'                                                
    '\u060c'                            
    '\ufe9d'                                                
    '\ufea1'                                               
    '\ufea5'                                                
    '\u0660'                                       
    '\u0661'                                      
    '\u0662'                                      
    '\u0663'                                        
    '\u0664'                                       
    '\u0665'                                       
    '\u0666'                                      
    '\u0667'                                        
    '\u0668'                                        
    '\u0669'                                       
    '\ufed1'                                               
    '\u061b'                                
    '\ufeb1'                                                
    '\ufeb5'                                                 
    '\ufeb9'                                               
    '\u061f'                                    
    '\xa2'                           
    '\ufe80'                                                 
    '\ufe81'                                                                 
    '\ufe83'                                                                 
    '\ufe85'                                                                
    '\ufeca'                                            
    '\ufe8b'                                                               
    '\ufe8d'                                                
    '\ufe91'                                              
    '\ufe93'                                                       
    '\ufe97'                                              
    '\ufe9b'                                               
    '\ufe9f'                                               
    '\ufea3'                                              
    '\ufea7'                                               
    '\ufea9'                                               
    '\ufeab'                                                
    '\ufead'                                               
    '\ufeaf'                                                
    '\ufeb3'                                               
    '\ufeb7'                                                
    '\ufebb'                                              
    '\ufebf'                                              
    '\ufec1'                                               
    '\ufec5'                                               
    '\ufecb'                                              
    '\ufecf'                                                
    '\xa6'                                     
    '\xac'                          
    '\xf7'                               
    '\xd7'                                     
    '\ufec9'                                               
    '\u0640'                              
    '\ufed3'                                              
    '\ufed7'                                              
    '\ufedb'                                              
    '\ufedf'                                              
    '\ufee3'                                               
    '\ufee7'                                               
    '\ufeeb'                                              
    '\ufeed'                                               
    '\ufeef'                                                        
    '\ufef3'                                              
    '\ufebd'                                               
    '\ufecc'                                             
    '\ufece'                                              
    '\ufecd'                                                 
    '\ufee1'                                                
    '\ufe7d'                                         
    '\u0651'                              
    '\ufee5'                                                
    '\ufee9'                                               
    '\ufeec'                                             
    '\ufef0'                                                     
    '\ufef2'                                            
    '\ufed0'                                               
    '\ufed5'                                               
    '\ufef5'                                                                            
    '\ufef6'                                                                         
    '\ufedd'                                               
    '\ufed9'                                               
    '\ufef1'                                               
    '\u25a0'                            
    '\ufffe'                         
)

                

encoding_map = {
    0x0000: 0x0000,            
    0x0001: 0x0001,                        
    0x0002: 0x0002,                     
    0x0003: 0x0003,                   
    0x0004: 0x0004,                           
    0x0005: 0x0005,               
    0x0006: 0x0006,                   
    0x0007: 0x0007,            
    0x0008: 0x0008,                 
    0x0009: 0x0009,                             
    0x000a: 0x000a,                 
    0x000b: 0x000b,                           
    0x000c: 0x000c,                 
    0x000d: 0x000d,                       
    0x000e: 0x000e,                 
    0x000f: 0x000f,                
    0x0010: 0x0010,                        
    0x0011: 0x0011,                          
    0x0012: 0x0012,                          
    0x0013: 0x0013,                            
    0x0014: 0x0014,                           
    0x0015: 0x0015,                            
    0x0016: 0x0016,                        
    0x0017: 0x0017,                                 
    0x0018: 0x0018,              
    0x0019: 0x0019,                     
    0x001a: 0x001a,                  
    0x001b: 0x001b,              
    0x001c: 0x001c,                      
    0x001d: 0x001d,                       
    0x001e: 0x001e,                        
    0x001f: 0x001f,                      
    0x0020: 0x0020,             
    0x0021: 0x0021,                        
    0x0022: 0x0022,                      
    0x0023: 0x0023,                   
    0x0024: 0x0024,                   
    0x0026: 0x0026,                 
    0x0027: 0x0027,                  
    0x0028: 0x0028,                        
    0x0029: 0x0029,                         
    0x002a: 0x002a,                
    0x002b: 0x002b,                 
    0x002c: 0x002c,             
    0x002d: 0x002d,                    
    0x002e: 0x002e,                 
    0x002f: 0x002f,               
    0x0030: 0x0030,                  
    0x0031: 0x0031,                 
    0x0032: 0x0032,                 
    0x0033: 0x0033,                   
    0x0034: 0x0034,                  
    0x0035: 0x0035,                  
    0x0036: 0x0036,                 
    0x0037: 0x0037,                   
    0x0038: 0x0038,                   
    0x0039: 0x0039,                  
    0x003a: 0x003a,             
    0x003b: 0x003b,                 
    0x003c: 0x003c,                      
    0x003d: 0x003d,                   
    0x003e: 0x003e,                         
    0x003f: 0x003f,                     
    0x0040: 0x0040,                     
    0x0041: 0x0041,                              
    0x0042: 0x0042,                              
    0x0043: 0x0043,                              
    0x0044: 0x0044,                              
    0x0045: 0x0045,                              
    0x0046: 0x0046,                              
    0x0047: 0x0047,                              
    0x0048: 0x0048,                              
    0x0049: 0x0049,                              
    0x004a: 0x004a,                              
    0x004b: 0x004b,                              
    0x004c: 0x004c,                              
    0x004d: 0x004d,                              
    0x004e: 0x004e,                              
    0x004f: 0x004f,                              
    0x0050: 0x0050,                              
    0x0051: 0x0051,                              
    0x0052: 0x0052,                              
    0x0053: 0x0053,                              
    0x0054: 0x0054,                              
    0x0055: 0x0055,                              
    0x0056: 0x0056,                              
    0x0057: 0x0057,                              
    0x0058: 0x0058,                              
    0x0059: 0x0059,                              
    0x005a: 0x005a,                              
    0x005b: 0x005b,                           
    0x005c: 0x005c,                       
    0x005d: 0x005d,                            
    0x005e: 0x005e,                         
    0x005f: 0x005f,                
    0x0060: 0x0060,                    
    0x0061: 0x0061,                            
    0x0062: 0x0062,                            
    0x0063: 0x0063,                            
    0x0064: 0x0064,                            
    0x0065: 0x0065,                            
    0x0066: 0x0066,                            
    0x0067: 0x0067,                            
    0x0068: 0x0068,                            
    0x0069: 0x0069,                            
    0x006a: 0x006a,                            
    0x006b: 0x006b,                            
    0x006c: 0x006c,                            
    0x006d: 0x006d,                            
    0x006e: 0x006e,                            
    0x006f: 0x006f,                            
    0x0070: 0x0070,                            
    0x0071: 0x0071,                            
    0x0072: 0x0072,                            
    0x0073: 0x0073,                            
    0x0074: 0x0074,                            
    0x0075: 0x0075,                            
    0x0076: 0x0076,                            
    0x0077: 0x0077,                            
    0x0078: 0x0078,                            
    0x0079: 0x0079,                            
    0x007a: 0x007a,                            
    0x007b: 0x007b,                          
    0x007c: 0x007c,                     
    0x007d: 0x007d,                           
    0x007e: 0x007e,             
    0x007f: 0x007f,              
    0x00a0: 0x00a0,                          
    0x00a2: 0x00c0,                 
    0x00a3: 0x00a3,                  
    0x00a4: 0x00a4,                     
    0x00a6: 0x00db,                           
    0x00ab: 0x0097,                               
    0x00ac: 0x00dc,                
    0x00ad: 0x00a1,                   
    0x00b0: 0x0080,                   
    0x00b1: 0x0093,                          
    0x00b7: 0x0081,                  
    0x00bb: 0x0098,                                
    0x00bc: 0x0095,                    
    0x00bd: 0x0094,                    
    0x00d7: 0x00de,                           
    0x00f7: 0x00dd,                     
    0x03b2: 0x0090,                        
    0x03c6: 0x0092,                       
    0x060c: 0x00ac,                    
    0x061b: 0x00bb,                        
    0x061f: 0x00bf,                            
    0x0640: 0x00e0,                      
    0x0651: 0x00f1,                      
    0x0660: 0x00b0,                               
    0x0661: 0x00b1,                              
    0x0662: 0x00b2,                              
    0x0663: 0x00b3,                                
    0x0664: 0x00b4,                               
    0x0665: 0x00b5,                               
    0x0666: 0x00b6,                              
    0x0667: 0x00b7,                                
    0x0668: 0x00b8,                                
    0x0669: 0x00b9,                               
    0x066a: 0x0025,                           
    0x2219: 0x0082,                       
    0x221a: 0x0083,                   
    0x221e: 0x0091,                
    0x2248: 0x0096,                       
    0x2500: 0x0085,                              
    0x2502: 0x0086,                            
    0x250c: 0x008d,                                  
    0x2510: 0x008c,                                 
    0x2514: 0x008e,                                
    0x2518: 0x008f,                               
    0x251c: 0x008a,                                      
    0x2524: 0x0088,                                     
    0x252c: 0x0089,                                       
    0x2534: 0x008b,                                     
    0x253c: 0x0087,                                           
    0x2592: 0x0084,                    
    0x25a0: 0x00fe,                    
    0xfe7d: 0x00f0,                                 
    0xfe80: 0x00c1,                                         
    0xfe81: 0x00c2,                                                         
    0xfe82: 0x00a2,                                                      
    0xfe83: 0x00c3,                                                         
    0xfe84: 0x00a5,                                                      
    0xfe85: 0x00c4,                                                        
    0xfe8b: 0x00c6,                                                       
    0xfe8d: 0x00c7,                                        
    0xfe8e: 0x00a8,                                     
    0xfe8f: 0x00a9,                                       
    0xfe91: 0x00c8,                                      
    0xfe93: 0x00c9,                                               
    0xfe95: 0x00aa,                                       
    0xfe97: 0x00ca,                                      
    0xfe99: 0x00ab,                                        
    0xfe9b: 0x00cb,                                       
    0xfe9d: 0x00ad,                                        
    0xfe9f: 0x00cc,                                       
    0xfea1: 0x00ae,                                       
    0xfea3: 0x00cd,                                      
    0xfea5: 0x00af,                                        
    0xfea7: 0x00ce,                                       
    0xfea9: 0x00cf,                                       
    0xfeab: 0x00d0,                                        
    0xfead: 0x00d1,                                       
    0xfeaf: 0x00d2,                                        
    0xfeb1: 0x00bc,                                        
    0xfeb3: 0x00d3,                                       
    0xfeb5: 0x00bd,                                         
    0xfeb7: 0x00d4,                                        
    0xfeb9: 0x00be,                                       
    0xfebb: 0x00d5,                                      
    0xfebd: 0x00eb,                                       
    0xfebf: 0x00d6,                                      
    0xfec1: 0x00d7,                                       
    0xfec5: 0x00d8,                                       
    0xfec9: 0x00df,                                       
    0xfeca: 0x00c5,                                    
    0xfecb: 0x00d9,                                      
    0xfecc: 0x00ec,                                     
    0xfecd: 0x00ee,                                         
    0xfece: 0x00ed,                                      
    0xfecf: 0x00da,                                        
    0xfed0: 0x00f7,                                       
    0xfed1: 0x00ba,                                       
    0xfed3: 0x00e1,                                      
    0xfed5: 0x00f8,                                       
    0xfed7: 0x00e2,                                      
    0xfed9: 0x00fc,                                       
    0xfedb: 0x00e3,                                      
    0xfedd: 0x00fb,                                       
    0xfedf: 0x00e4,                                      
    0xfee1: 0x00ef,                                        
    0xfee3: 0x00e5,                                       
    0xfee5: 0x00f2,                                        
    0xfee7: 0x00e6,                                       
    0xfee9: 0x00f3,                                       
    0xfeeb: 0x00e7,                                      
    0xfeec: 0x00f4,                                     
    0xfeed: 0x00e8,                                       
    0xfeef: 0x00e9,                                                
    0xfef0: 0x00f5,                                             
    0xfef1: 0x00fd,                                       
    0xfef2: 0x00f6,                                    
    0xfef3: 0x00ea,                                      
    0xfef5: 0x00f9,                                                                    
    0xfef6: 0x00fa,                                                                 
    0xfef7: 0x0099,                                                                    
    0xfef8: 0x009a,                                                                 
    0xfefb: 0x009d,                                                   
    0xfefc: 0x009e,                                                
}
