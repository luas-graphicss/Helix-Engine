""" Python Character Mapping Codec generated from 'VENDORS/APPLE/ARABIC.TXT' with gencodec.py.

"""  

import codecs

              

class Codec(codecs.Codec):

    def encode(self,input,errors='strict'):
        return codecs.charmap_encode(input,errors,encoding_map)

    def decode(self,input,errors='strict'):
        return codecs.charmap_decode(input,errors,decoding_table)

class IncrementalEncoder(codecs.IncrementalEncoder):
    def encode(self, input, final=False):
        return codecs.charmap_encode(input,self.errors,encoding_map)[0]

class IncrementalDecoder(codecs.IncrementalDecoder):
    def decode(self, input, final=False):
        return codecs.charmap_decode(input,self.errors,decoding_table)[0]

class StreamWriter(Codec,codecs.StreamWriter):
    pass

class StreamReader(Codec,codecs.StreamReader):
    pass

                        

def getregentry():
    return codecs.CodecInfo(
        name='mac-arabic',
        encode=Codec().encode,
        decode=Codec().decode,
        incrementalencoder=IncrementalEncoder,
        incrementaldecoder=IncrementalDecoder,
        streamreader=StreamReader,
        streamwriter=StreamWriter,
    )

                

decoding_map = codecs.make_identity_dict(range(256))
decoding_map.update({
    0x0080: 0x00c4,                                             
    0x0081: 0x00a0,                                  
    0x0082: 0x00c7,                                           
    0x0083: 0x00c9,                                         
    0x0084: 0x00d1,                                         
    0x0085: 0x00d6,                                             
    0x0086: 0x00dc,                                             
    0x0087: 0x00e1,                                       
    0x0088: 0x00e0,                                       
    0x0089: 0x00e2,                                            
    0x008a: 0x00e4,                                           
    0x008b: 0x06ba,                                 
    0x008c: 0x00ab,                                                             
    0x008d: 0x00e7,                                         
    0x008e: 0x00e9,                                       
    0x008f: 0x00e8,                                       
    0x0090: 0x00ea,                                            
    0x0091: 0x00eb,                                           
    0x0092: 0x00ed,                                       
    0x0093: 0x2026,                                       
    0x0094: 0x00ee,                                            
    0x0095: 0x00ef,                                           
    0x0096: 0x00f1,                                       
    0x0097: 0x00f3,                                       
    0x0098: 0x00bb,                                                              
    0x0099: 0x00f4,                                            
    0x009a: 0x00f6,                                           
    0x009b: 0x00f7,                                 
    0x009c: 0x00fa,                                       
    0x009d: 0x00f9,                                       
    0x009e: 0x00fb,                                            
    0x009f: 0x00fc,                                           
    0x00a0: 0x0020,                         
    0x00a1: 0x0021,                                    
    0x00a2: 0x0022,                                  
    0x00a3: 0x0023,                               
    0x00a4: 0x0024,                               
    0x00a5: 0x066a,                           
    0x00a6: 0x0026,                             
    0x00a7: 0x0027,                              
    0x00a8: 0x0028,                                    
    0x00a9: 0x0029,                                     
    0x00aa: 0x002a,                            
    0x00ab: 0x002b,                             
    0x00ac: 0x060c,                    
    0x00ad: 0x002d,                                
    0x00ae: 0x002e,                             
    0x00af: 0x002f,                           
    0x00b0: 0x0660,                                                           
    0x00b1: 0x0661,                                                          
    0x00b2: 0x0662,                                                          
    0x00b3: 0x0663,                                                            
    0x00b4: 0x0664,                                                           
    0x00b5: 0x0665,                                                           
    0x00b6: 0x0666,                                                          
    0x00b7: 0x0667,                                                            
    0x00b8: 0x0668,                                                            
    0x00b9: 0x0669,                                                           
    0x00ba: 0x003a,                         
    0x00bb: 0x061b,                        
    0x00bc: 0x003c,                                  
    0x00bd: 0x003d,                               
    0x00be: 0x003e,                                     
    0x00bf: 0x061f,                            
    0x00c0: 0x274a,                                                            
    0x00c1: 0x0621,                           
    0x00c2: 0x0622,                                           
    0x00c3: 0x0623,                                           
    0x00c4: 0x0624,                                          
    0x00c5: 0x0625,                                           
    0x00c6: 0x0626,                                          
    0x00c7: 0x0627,                          
    0x00c8: 0x0628,                         
    0x00c9: 0x0629,                                 
    0x00ca: 0x062a,                         
    0x00cb: 0x062b,                          
    0x00cc: 0x062c,                          
    0x00cd: 0x062d,                         
    0x00ce: 0x062e,                          
    0x00cf: 0x062f,                         
    0x00d0: 0x0630,                          
    0x00d1: 0x0631,                         
    0x00d2: 0x0632,                          
    0x00d3: 0x0633,                          
    0x00d4: 0x0634,                           
    0x00d5: 0x0635,                         
    0x00d6: 0x0636,                         
    0x00d7: 0x0637,                         
    0x00d8: 0x0638,                         
    0x00d9: 0x0639,                         
    0x00da: 0x063a,                           
    0x00db: 0x005b,                                       
    0x00dc: 0x005c,                                   
    0x00dd: 0x005d,                                        
    0x00de: 0x005e,                                     
    0x00df: 0x005f,                            
    0x00e0: 0x0640,                      
    0x00e1: 0x0641,                         
    0x00e2: 0x0642,                         
    0x00e3: 0x0643,                         
    0x00e4: 0x0644,                         
    0x00e5: 0x0645,                          
    0x00e6: 0x0646,                          
    0x00e7: 0x0647,                         
    0x00e8: 0x0648,                         
    0x00e9: 0x0649,                                  
    0x00ea: 0x064a,                         
    0x00eb: 0x064b,                       
    0x00ec: 0x064c,                       
    0x00ed: 0x064d,                       
    0x00ee: 0x064e,                    
    0x00ef: 0x064f,                    
    0x00f0: 0x0650,                    
    0x00f1: 0x0651,                     
    0x00f2: 0x0652,                    
    0x00f3: 0x067e,                         
    0x00f4: 0x0679,                          
    0x00f5: 0x0686,                           
    0x00f6: 0x06d5,                        
    0x00f7: 0x06a4,                         
    0x00f8: 0x06af,                         
    0x00f9: 0x0688,                          
    0x00fa: 0x0691,                          
    0x00fb: 0x007b,                                      
    0x00fc: 0x007c,                                 
    0x00fd: 0x007d,                                       
    0x00fe: 0x0698,                         
    0x00ff: 0x06d2,                                
})

                  

decoding_table = (
    '\x00'                                   
    '\x01'                                   
    '\x02'                                   
    '\x03'                                   
    '\x04'                                   
    '\x05'                                   
    '\x06'                                   
    '\x07'                                   
    '\x08'                                   
    '\t'                                     
    '\n'                                     
    '\x0b'                                   
    '\x0c'                                   
    '\r'                                     
    '\x0e'                                   
    '\x0f'                                   
    '\x10'                                   
    '\x11'                                   
    '\x12'                                   
    '\x13'                                   
    '\x14'                                   
    '\x15'                                   
    '\x16'                                   
    '\x17'                                   
    '\x18'                                   
    '\x19'                                   
    '\x1a'                                   
    '\x1b'                                   
    '\x1c'                                   
    '\x1d'                                   
    '\x1e'                                   
    '\x1f'                                   
    ' '                                      
    '!'                                                 
    '"'                                               
    '#'                                            
    '$'                                            
    '%'                                             
    '&'                                          
    "'"                                           
    '('                                                 
    ')'                                                  
    '*'                                         
    '+'                                          
    ','                                                                                                                
    '-'                                             
    '.'                                                                                                                  
    '/'                                        
    '0'                                                                                                       
    '1'                                                                                                      
    '2'                                                                                                      
    '3'                                                                                                        
    '4'                                                                                                       
    '5'                                                                                                       
    '6'                                                                                                      
    '7'                                                                                                        
    '8'                                                                                                        
    '9'                                                                                                       
    ':'                                      
    ';'                                          
    '<'                                               
    '='                                            
    '>'                                                  
    '?'                                              
    '@'                                  
    'A'                                           
    'B'                                           
    'C'                                           
    'D'                                           
    'E'                                           
    'F'                                           
    'G'                                           
    'H'                                           
    'I'                                           
    'J'                                           
    'K'                                           
    'L'                                           
    'M'                                           
    'N'                                           
    'O'                                           
    'P'                                           
    'Q'                                           
    'R'                                           
    'S'                                           
    'T'                                           
    'U'                                           
    'V'                                           
    'W'                                           
    'X'                                           
    'Y'                                           
    'Z'                                           
    '['                                                    
    '\\'                                               
    ']'                                                     
    '^'                                                  
    '_'                                         
    '`'                                 
    'a'                                         
    'b'                                         
    'c'                                         
    'd'                                         
    'e'                                         
    'f'                                         
    'g'                                         
    'h'                                         
    'i'                                         
    'j'                                         
    'k'                                         
    'l'                                         
    'm'                                         
    'n'                                         
    'o'                                         
    'p'                                         
    'q'                                         
    'r'                                         
    's'                                         
    't'                                         
    'u'                                         
    'v'                                         
    'w'                                         
    'x'                                         
    'y'                                         
    'z'                                         
    '{'                                                   
    '|'                                              
    '}'                                                    
    '~'                          
    '\x7f'                                   
    '\xc4'                                                       
    '\xa0'                                            
    '\xc7'                                                     
    '\xc9'                                                   
    '\xd1'                                                   
    '\xd6'                                                       
    '\xdc'                                                       
    '\xe1'                                                 
    '\xe0'                                                 
    '\xe2'                                                      
    '\xe4'                                                     
    '\u06ba'                                         
    '\xab'                                                                       
    '\xe7'                                                   
    '\xe9'                                                 
    '\xe8'                                                 
    '\xea'                                                      
    '\xeb'                                                     
    '\xed'                                                 
    '\u2026'                                               
    '\xee'                                                      
    '\xef'                                                     
    '\xf1'                                                 
    '\xf3'                                                 
    '\xbb'                                                                        
    '\xf4'                                                      
    '\xf6'                                                     
    '\xf7'                                           
    '\xfa'                                                 
    '\xf9'                                                 
    '\xfb'                                                      
    '\xfc'                                                     
    ' '                                      
    '!'                                                 
    '"'                                               
    '#'                                            
    '$'                                            
    '\u066a'                                   
    '&'                                          
    "'"                                           
    '('                                                 
    ')'                                                  
    '*'                                         
    '+'                                          
    '\u060c'                            
    '-'                                             
    '.'                                          
    '/'                                        
    '\u0660'                                                                   
    '\u0661'                                                                  
    '\u0662'                                                                  
    '\u0663'                                                                    
    '\u0664'                                                                   
    '\u0665'                                                                   
    '\u0666'                                                                  
    '\u0667'                                                                    
    '\u0668'                                                                    
    '\u0669'                                                                   
    ':'                                      
    '\u061b'                                
    '<'                                               
    '='                                            
    '>'                                                  
    '\u061f'                                    
    '\u274a'                                                                    
    '\u0621'                                   
    '\u0622'                                                   
    '\u0623'                                                   
    '\u0624'                                                  
    '\u0625'                                                   
    '\u0626'                                                  
    '\u0627'                                  
    '\u0628'                                 
    '\u0629'                                         
    '\u062a'                                 
    '\u062b'                                  
    '\u062c'                                  
    '\u062d'                                 
    '\u062e'                                  
    '\u062f'                                 
    '\u0630'                                  
    '\u0631'                                 
    '\u0632'                                  
    '\u0633'                                  
    '\u0634'                                   
    '\u0635'                                 
    '\u0636'                                 
    '\u0637'                                 
    '\u0638'                                 
    '\u0639'                                 
    '\u063a'                                   
    '['                                                    
    '\\'                                               
    ']'                                                     
    '^'                                                  
    '_'                                         
    '\u0640'                              
    '\u0641'                                 
    '\u0642'                                 
    '\u0643'                                 
    '\u0644'                                 
    '\u0645'                                  
    '\u0646'                                  
    '\u0647'                                 
    '\u0648'                                 
    '\u0649'                                          
    '\u064a'                                 
    '\u064b'                               
    '\u064c'                               
    '\u064d'                               
    '\u064e'                            
    '\u064f'                            
    '\u0650'                            
    '\u0651'                             
    '\u0652'                            
    '\u067e'                                 
    '\u0679'                                  
    '\u0686'                                   
    '\u06d5'                                
    '\u06a4'                                 
    '\u06af'                                 
    '\u0688'                                  
    '\u0691'                                  
    '{'                                                   
    '|'                                              
    '}'                                                    
    '\u0698'                                 
    '\u06d2'                                        
)

                

encoding_map = {
    0x0000: 0x0000,                         
    0x0001: 0x0001,                         
    0x0002: 0x0002,                         
    0x0003: 0x0003,                         
    0x0004: 0x0004,                         
    0x0005: 0x0005,                         
    0x0006: 0x0006,                         
    0x0007: 0x0007,                         
    0x0008: 0x0008,                         
    0x0009: 0x0009,                         
    0x000a: 0x000a,                         
    0x000b: 0x000b,                         
    0x000c: 0x000c,                         
    0x000d: 0x000d,                         
    0x000e: 0x000e,                         
    0x000f: 0x000f,                         
    0x0010: 0x0010,                         
    0x0011: 0x0011,                         
    0x0012: 0x0012,                         
    0x0013: 0x0013,                         
    0x0014: 0x0014,                         
    0x0015: 0x0015,                         
    0x0016: 0x0016,                         
    0x0017: 0x0017,                         
    0x0018: 0x0018,                         
    0x0019: 0x0019,                         
    0x001a: 0x001a,                         
    0x001b: 0x001b,                         
    0x001c: 0x001c,                         
    0x001d: 0x001d,                         
    0x001e: 0x001e,                         
    0x001f: 0x001f,                         
    0x0020: 0x0020,                         
    0x0020: 0x00a0,                         
    0x0021: 0x0021,                                    
    0x0021: 0x00a1,                                    
    0x0022: 0x0022,                                  
    0x0022: 0x00a2,                                  
    0x0023: 0x0023,                               
    0x0023: 0x00a3,                               
    0x0024: 0x0024,                               
    0x0024: 0x00a4,                               
    0x0025: 0x0025,                                
    0x0026: 0x0026,                             
    0x0026: 0x00a6,                             
    0x0027: 0x0027,                              
    0x0027: 0x00a7,                              
    0x0028: 0x0028,                                    
    0x0028: 0x00a8,                                    
    0x0029: 0x0029,                                     
    0x0029: 0x00a9,                                     
    0x002a: 0x002a,                            
    0x002a: 0x00aa,                            
    0x002b: 0x002b,                             
    0x002b: 0x00ab,                             
    0x002c: 0x002c,                                                                                                   
    0x002d: 0x002d,                                
    0x002d: 0x00ad,                                
    0x002e: 0x002e,                                                                                                     
    0x002e: 0x00ae,                             
    0x002f: 0x002f,                           
    0x002f: 0x00af,                           
    0x0030: 0x0030,                                                                                          
    0x0031: 0x0031,                                                                                         
    0x0032: 0x0032,                                                                                         
    0x0033: 0x0033,                                                                                           
    0x0034: 0x0034,                                                                                          
    0x0035: 0x0035,                                                                                          
    0x0036: 0x0036,                                                                                         
    0x0037: 0x0037,                                                                                           
    0x0038: 0x0038,                                                                                           
    0x0039: 0x0039,                                                                                          
    0x003a: 0x003a,                         
    0x003a: 0x00ba,                         
    0x003b: 0x003b,                             
    0x003c: 0x003c,                                  
    0x003c: 0x00bc,                                  
    0x003d: 0x003d,                               
    0x003d: 0x00bd,                               
    0x003e: 0x003e,                                     
    0x003e: 0x00be,                                     
    0x003f: 0x003f,                                 
    0x0040: 0x0040,                     
    0x0041: 0x0041,                              
    0x0042: 0x0042,                              
    0x0043: 0x0043,                              
    0x0044: 0x0044,                              
    0x0045: 0x0045,                              
    0x0046: 0x0046,                              
    0x0047: 0x0047,                              
    0x0048: 0x0048,                              
    0x0049: 0x0049,                              
    0x004a: 0x004a,                              
    0x004b: 0x004b,                              
    0x004c: 0x004c,                              
    0x004d: 0x004d,                              
    0x004e: 0x004e,                              
    0x004f: 0x004f,                              
    0x0050: 0x0050,                              
    0x0051: 0x0051,                              
    0x0052: 0x0052,                              
    0x0053: 0x0053,                              
    0x0054: 0x0054,                              
    0x0055: 0x0055,                              
    0x0056: 0x0056,                              
    0x0057: 0x0057,                              
    0x0058: 0x0058,                              
    0x0059: 0x0059,                              
    0x005a: 0x005a,                              
    0x005b: 0x005b,                                       
    0x005b: 0x00db,                                       
    0x005c: 0x005c,                                   
    0x005c: 0x00dc,                                   
    0x005d: 0x005d,                                        
    0x005d: 0x00dd,                                        
    0x005e: 0x005e,                                     
    0x005e: 0x00de,                                     
    0x005f: 0x005f,                            
    0x005f: 0x00df,                            
    0x0060: 0x0060,                    
    0x0061: 0x0061,                            
    0x0062: 0x0062,                            
    0x0063: 0x0063,                            
    0x0064: 0x0064,                            
    0x0065: 0x0065,                            
    0x0066: 0x0066,                            
    0x0067: 0x0067,                            
    0x0068: 0x0068,                            
    0x0069: 0x0069,                            
    0x006a: 0x006a,                            
    0x006b: 0x006b,                            
    0x006c: 0x006c,                            
    0x006d: 0x006d,                            
    0x006e: 0x006e,                            
    0x006f: 0x006f,                            
    0x0070: 0x0070,                            
    0x0071: 0x0071,                            
    0x0072: 0x0072,                            
    0x0073: 0x0073,                            
    0x0074: 0x0074,                            
    0x0075: 0x0075,                            
    0x0076: 0x0076,                            
    0x0077: 0x0077,                            
    0x0078: 0x0078,                            
    0x0079: 0x0079,                            
    0x007a: 0x007a,                            
    0x007b: 0x007b,                                      
    0x007b: 0x00fb,                                      
    0x007c: 0x007c,                                 
    0x007c: 0x00fc,                                 
    0x007d: 0x007d,                                       
    0x007d: 0x00fd,                                       
    0x007e: 0x007e,             
    0x007f: 0x007f,                         
    0x00a0: 0x0081,                                  
    0x00ab: 0x008c,                                                             
    0x00bb: 0x0098,                                                              
    0x00c4: 0x0080,                                             
    0x00c7: 0x0082,                                           
    0x00c9: 0x0083,                                         
    0x00d1: 0x0084,                                         
    0x00d6: 0x0085,                                             
    0x00dc: 0x0086,                                             
    0x00e0: 0x0088,                                       
    0x00e1: 0x0087,                                       
    0x00e2: 0x0089,                                            
    0x00e4: 0x008a,                                           
    0x00e7: 0x008d,                                         
    0x00e8: 0x008f,                                       
    0x00e9: 0x008e,                                       
    0x00ea: 0x0090,                                            
    0x00eb: 0x0091,                                           
    0x00ed: 0x0092,                                       
    0x00ee: 0x0094,                                            
    0x00ef: 0x0095,                                           
    0x00f1: 0x0096,                                       
    0x00f3: 0x0097,                                       
    0x00f4: 0x0099,                                            
    0x00f6: 0x009a,                                           
    0x00f7: 0x009b,                                 
    0x00f9: 0x009d,                                       
    0x00fa: 0x009c,                                       
    0x00fb: 0x009e,                                            
    0x00fc: 0x009f,                                           
    0x060c: 0x00ac,                    
    0x061b: 0x00bb,                        
    0x061f: 0x00bf,                            
    0x0621: 0x00c1,                           
    0x0622: 0x00c2,                                           
    0x0623: 0x00c3,                                           
    0x0624: 0x00c4,                                          
    0x0625: 0x00c5,                                           
    0x0626: 0x00c6,                                          
    0x0627: 0x00c7,                          
    0x0628: 0x00c8,                         
    0x0629: 0x00c9,                                 
    0x062a: 0x00ca,                         
    0x062b: 0x00cb,                          
    0x062c: 0x00cc,                          
    0x062d: 0x00cd,                         
    0x062e: 0x00ce,                          
    0x062f: 0x00cf,                         
    0x0630: 0x00d0,                          
    0x0631: 0x00d1,                         
    0x0632: 0x00d2,                          
    0x0633: 0x00d3,                          
    0x0634: 0x00d4,                           
    0x0635: 0x00d5,                         
    0x0636: 0x00d6,                         
    0x0637: 0x00d7,                         
    0x0638: 0x00d8,                         
    0x0639: 0x00d9,                         
    0x063a: 0x00da,                           
    0x0640: 0x00e0,                      
    0x0641: 0x00e1,                         
    0x0642: 0x00e2,                         
    0x0643: 0x00e3,                         
    0x0644: 0x00e4,                         
    0x0645: 0x00e5,                          
    0x0646: 0x00e6,                          
    0x0647: 0x00e7,                         
    0x0648: 0x00e8,                         
    0x0649: 0x00e9,                                  
    0x064a: 0x00ea,                         
    0x064b: 0x00eb,                       
    0x064c: 0x00ec,                       
    0x064d: 0x00ed,                       
    0x064e: 0x00ee,                    
    0x064f: 0x00ef,                    
    0x0650: 0x00f0,                    
    0x0651: 0x00f1,                     
    0x0652: 0x00f2,                    
    0x0660: 0x00b0,                                                           
    0x0661: 0x00b1,                                                          
    0x0662: 0x00b2,                                                          
    0x0663: 0x00b3,                                                            
    0x0664: 0x00b4,                                                           
    0x0665: 0x00b5,                                                           
    0x0666: 0x00b6,                                                          
    0x0667: 0x00b7,                                                            
    0x0668: 0x00b8,                                                            
    0x0669: 0x00b9,                                                           
    0x066a: 0x00a5,                           
    0x0679: 0x00f4,                          
    0x067e: 0x00f3,                         
    0x0686: 0x00f5,                           
    0x0688: 0x00f9,                          
    0x0691: 0x00fa,                          
    0x0698: 0x00fe,                         
    0x06a4: 0x00f7,                         
    0x06af: 0x00f8,                         
    0x06ba: 0x008b,                                 
    0x06d2: 0x00ff,                                
    0x06d5: 0x00f6,                        
    0x2026: 0x0093,                                       
    0x274a: 0x00c0,                                                            
}
