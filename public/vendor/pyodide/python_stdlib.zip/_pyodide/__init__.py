                                                                                
                                                      
 
                                                                                
              
 
                                                                           
                                                                               
          
from . import _base, _importhook

__all__ = ["_base", "_importhook"]


def set_excepthook():
    import sys
    import traceback

                                                                   
                                                                            
                                                                            
                                                                         
                                                                             
                                                                               
                                                                                
                                        
     
                                                                                
                             
    sys.excepthook = traceback.print_exception
