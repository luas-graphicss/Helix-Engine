                              
                                              
                                                

__all__ = ("loads", "load", "TOMLDecodeError")

from ._parser import TOMLDecodeError, load, loads

                                          
TOMLDecodeError.__module__ = __name__
